#ifndef _NODE_H_
#define _NODE_H_

#include <iostream>
#include <ros/ros.h>
#include <ros/console.h>
#include <Eigen/Eigen>
#include "backward.hpp"

#define inf 1>>20
struct GridNode;
typedef GridNode* GridNodePtr;
struct HybridNode;
typedef HybridNode* HybridNodePtr;

struct GridNode
{     
    int id;        // 1--> open set, -1 --> closed set
    Eigen::Vector2d coord; 
    Eigen::Vector2i dir;   // direction of expanding
    Eigen::Vector2i index;

	  std::vector<Eigen::Vector2d> Position;
    std::vector<Eigen::Vector2d> Velocity;
    double gScore, fScore;
    GridNodePtr cameFrom;
    std::multimap<double, GridNodePtr>::iterator nodeMapIt;

    GridNode(Eigen::Vector2i _index, Eigen::Vector2d _coord){  
		id = 0;
		index = _index;
		coord = _coord;
		dir   = Eigen::Vector2i::Zero();

		gScore = inf;
		fScore = inf;
		cameFrom = NULL;
    }

    GridNode(){};
    ~GridNode(){};
};

struct HybridNode
{     
    int id;        // 1--> open set, -1 --> closed set
    Eigen::Vector2d coord; 
    Eigen::Vector2i dir;   // direction of expanding
    Eigen::Vector2i index;
    Eigen::Vector2d vel;
    Eigen::Vector2d acc;
    double theta,v_theta,omega_turn,omega_front,phi;
    std::vector<Eigen::Vector2d> Positionpts;
    double gScore, fScore;
    HybridNodePtr cameFrom;
    std::multimap<double,   HybridNodePtr>::iterator nodeMapIt;

    HybridNode(Eigen::Vector2i _index, Eigen::Vector2d _coord){  
		id = 0;
		index = _index;
		coord = _coord;
		dir   = Eigen::Vector2i::Zero();

		gScore = inf;
		fScore = inf;
		cameFrom = NULL;
    }

    HybridNode(){};
    ~HybridNode(){};
};



#endif
