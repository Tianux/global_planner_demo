#include <iostream>
#include <fstream>
#include <math.h>
#include <pcl_conversions/pcl_conversions.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <ros/ros.h>
#include <ros/console.h>
#include <sensor_msgs/PointCloud2.h>

#include <nav_msgs/Odometry.h>
#include <nav_msgs/Path.h>
#include <geometry_msgs/PoseStamped.h>
#include <visualization_msgs/MarkerArray.h>
#include <visualization_msgs/Marker.h>
#include <Astar_searcher.h>
#include "JPS_searcher.h"
#include <hw_tool.h>
#include "backward.hpp"

using namespace std;
using namespace Eigen;

namespace backward {
backward::SignalHandling sh;
}

// simulation param from launch file
double _resolution, _inv_resolution, _cloud_margin;
double _x_size, _y_size, _z_size;
Vector3d _start_pt, _start_velocity;

// useful global variables
bool _has_map   = false;

Vector3d _map_lower, _map_upper;
int _max_x_id, _max_y_id, _max_z_id;

// ros related
ros::Subscriber _map_sub, _pts_sub;
ros::Publisher  _grid_map_vis_pub, _path_vis_pub;
ros::Publisher  _grid_path_vis_pub, _visited_nodes_vis_pub;
visualization_msgs::MarkerArray  LineArray;
// Integral parameter
double _max_input_acc     = 1.0;
int    _discretize_step   = 4;
bool firstloop = true;
double _time_interval     = 0.8;//1.25;
int    _time_step         = 25;
int marker_id = 0;
Homeworktool * _homework_tool     = new Homeworktool();
TrajectoryStatePtr ** TraLibrary;
LatticeStatePtr ** TraLibrary_Lattice;
vector<LatticeStatePtr> Ptrlist;
AstarPathFinder * _astar_path_finder     = new AstarPathFinder();

void visGridPath( vector<Vector2d> nodes );
void visHybridGridPath( HybridNodePtr ptr );
void visVisitedNode( vector<Vector2d> nodes );
void rcvWaypointsCallback(const nav_msgs::Path & wp);
void rcvPointCloudCallBack(const sensor_msgs::PointCloud2 & pointcloud_map);
void trajectoryLibrary(const Eigen::Vector3d start_pt, const Eigen::Vector3d start_velocity, const Eigen::Vector3d target_pt);
void visTraLibrary(LatticeStatePtr ** TraLibrary);
void trajectory_init_lattice(const Vector3d start_pt, const Vector3d start_velocity, const Vector3d target_pt, LatticeStatePtr  fatherptr);
void lattice_graph(const Vector3d start_pt, const Vector3d start_velocity, const Vector3d target_pt);
void pathFinding(const Vector3d start_pt, const Vector3d target_pt);
void HybridpathFinding(const Vector3d start_pt, const Vector3d target_pt);

void rcvWaypointsCallback(const nav_msgs::Path & wp)
{     
    if( wp.poses[0].pose.position.z < 0.0 || _has_map == false )
        return;

    Vector3d target_pt;
    target_pt << wp.poses[0].pose.position.x,
                 wp.poses[0].pose.position.y,
                 wp.poses[0].pose.position.z;
                 /*
    for (auto x: LineArray.markers){
        x.color.a = 0.0;
    }
     _path_vis_pub.publish(LineArray);    */
    ROS_INFO("[node] receive the planning target");
//    lattice_graph(_start_pt,_start_velocity,target_pt);
    HybridpathFinding(_start_pt,target_pt);
}

void rcvPointCloudCallBack(const sensor_msgs::PointCloud2 & pointcloud_map)
{   
    if(_has_map ) return;

    pcl::PointCloud<pcl::PointXYZ> cloud;
    pcl::PointCloud<pcl::PointXYZ> cloud_vis;
    sensor_msgs::PointCloud2 map_vis;

    pcl::fromROSMsg(pointcloud_map, cloud);
    
    if( (int)cloud.points.size() == 0 ) return;

    pcl::PointXYZ pt;
    /*
    for (int idx = 0; idx < (int)cloud.points.size(); idx++)
    {    
        pt = cloud.points[idx];        

        // set obstalces into grid map for path planning
        _homework_tool->setObs(pt.x, pt.y, pt.z);

        // for visualize only
        Vector3d cor_round = _homework_tool->coordRounding(Vector3d(pt.x, pt.y, pt.z));
        pt.x = cor_round(0);
        pt.y = cor_round(1);
        pt.z = cor_round(2);
        cloud_vis.points.push_back(pt);
    }

    cloud_vis.width    = cloud_vis.points.size();
    cloud_vis.height   = 1;
    cloud_vis.is_dense = true;

    pcl::toROSMsg(cloud_vis, map_vis);

    map_vis.header.frame_id = "/world";
    _grid_map_vis_pub.publish(map_vis);

    _has_map = true;*/
    for (int idx = 0; idx < (int)cloud.points.size(); idx++)
    {    
        pt = cloud.points[idx];        

        // set obstalces into grid map for path planning
        _astar_path_finder->setObs(pt.x, pt.y);

        // for visualize only
        Vector2d cor_round = _astar_path_finder->coordRounding(Vector2d(pt.x, pt.y));
        pt.x = cor_round(0);
        pt.y = cor_round(1);
        pt.z = 0;
        cloud_vis.points.push_back(pt);
    }

    cloud_vis.width    = cloud_vis.points.size();
    cloud_vis.height   = 1;
    cloud_vis.is_dense = true;

    pcl::toROSMsg(cloud_vis, map_vis);

    map_vis.header.frame_id = "/world";
    _grid_map_vis_pub.publish(map_vis);

    _has_map = true;
}

void pathFinding(const Vector3d start_pt, const Vector3d target_pt)
{
    //Call A* to search for a path
    Vector2d start_pt_2d, target_pt_2d;
    start_pt_2d(0) = start_pt(0);
    start_pt_2d(1) = start_pt(1);
    target_pt_2d(0) = target_pt(0);
    target_pt_2d(1) = target_pt(1);      
    _astar_path_finder->AstarGraphSearch(start_pt_2d, target_pt_2d);

    //Retrieve the path
    auto grid_path     = _astar_path_finder->getPath();
    auto visited_nodes = _astar_path_finder->getVisitedNodes();

    //Visualize the result
    visGridPath (grid_path);
    visVisitedNode(visited_nodes);

    //Reset map for next call
    _astar_path_finder->resetUsedGrids();

}

void HybridpathFinding(const Vector3d start_pt, const Vector3d target_pt)
{
    //Call A* to search for a path
    Vector2d start_pt_2d, target_pt_2d;
    start_pt_2d(0) = start_pt(0);
    start_pt_2d(1) = start_pt(1);
    target_pt_2d(0) = target_pt(0);
    target_pt_2d(1) = target_pt(1);      
    _astar_path_finder->HybridAstarGraphSearch(start_pt_2d, target_pt_2d);

    //Retrieve the path
 //   auto grid_path     = _astar_path_finder->HybridgetPath();
//    auto visited_nodes = _astar_path_finder->getVisitedNodes();

    //Visualize the result
 //  visHybridGridPath (grid_path);
//    visVisitedNode(visited_nodes);

    //Reset map for next call
    _astar_path_finder->resetHybridUsedGrids();

}



void lattice_graph(const Vector3d start_pt, const Vector3d start_velocity, const Vector3d target_pt){
    LatticeStatePtr **test_init; 
    LatticeStatePtr test;
    Vector2d pos,vel;
    Vector3d pos3,vel3;
    int num_instack;
    int lastloop;
    bool all_collision = true;
    stringstream num_str;
    string num_str_msg;
    trajectory_init_lattice(start_pt, start_velocity, target_pt,nullptr);
    num_instack = Ptrlist.size();
    num_str_msg = to_string(num_instack);
    ROS_INFO("num:[%s]",num_str_msg.c_str());
    int countwhile = 0;
    firstloop  = false;
    
    while (Ptrlist.empty() == false){
        test = Ptrlist.front();
        Ptrlist.erase(Ptrlist.begin());
        if (test->collision_check==true){
                continue;
        }
        if (test->loop  > 1 && test->loop != lastloop){
            if (all_collision){
                break;
            }
            else{
                all_collision = true;
            }
        }
        if (test->loop == 5){
            break;
        }
        pos=test->Position[test->Position.size()-1]; 
        vel = test->Velocity[test->Velocity.size()-1];     
        pos3(0)=pos(0);
        pos3(1)=pos(1);
        vel3(0)=vel(0);
        vel3(1)=vel(1);
        lastloop = test->loop;
        all_collision = all_collision & test->collision_check;
        trajectory_init_lattice(pos3, vel3, target_pt,test);
        countwhile++;
        //num_instack = Ptrlist.size();
        num_str_msg = to_string(lastloop);
        ROS_INFO("num:[%s]",num_str_msg.c_str());
        
    }
    ROS_INFO("finish");    
}



void trajectory_init_lattice(const Vector3d start_pt, const Vector3d start_velocity, const Vector3d target_pt, LatticeStatePtr fatherptr)
{
    LatticeStatePtr **thisTraLibrary; 
    Vector2d acc_input;
    Vector2d pos,vel;
    int a =0 ;
    int b =0 ;
    int thisloop;
    if (fatherptr == NULL){
        thisloop = 1;
    }
    else{
        thisloop = fatherptr->loop+1;
    }
    double min_Cost = 100000.0;
    double Trajctory_Cost;
    thisTraLibrary  = new LatticeStatePtr * [_discretize_step + 1];     //recored all trajectories after input

    for(int i=0; i <= _discretize_step; i++){           //acc_input_ax
        thisTraLibrary[i] = new LatticeStatePtr  [_discretize_step + 1];
        for(int j=0;j <= _discretize_step; j++){        //acc_input_ay


                vector<Vector2d> Position;
                vector<Vector2d> Velocity;
                acc_input(0) = double(-_max_input_acc + i * (2 * _max_input_acc / double(_discretize_step)) );
                acc_input(1) = double(-_max_input_acc + j * (2 * _max_input_acc / double(_discretize_step)) );
                
                pos(0) = start_pt(0);
                pos(1) = start_pt(1);

                vel(0) = start_velocity(0);
                vel(1) = start_velocity(1);

                Position.push_back(pos);
                Velocity.push_back(vel);

                bool collision = false;
                double delta_time;
                delta_time = _time_interval / double(_time_step);
                
                for(int step=0 ; step<=_time_step ; step ++){

                    pos(0) = pos(0) + vel(0)*delta_time + 0.5*acc_input(0)*delta_time*delta_time;
                    pos(1) = pos(1) + vel(1)*delta_time + 0.5*acc_input(1)*delta_time*delta_time;

                    vel(0) = vel(0) + acc_input(0)*delta_time;
                    vel(1) = vel(1) + acc_input(1)*delta_time;

                                       
                    Position.push_back(pos);
                    Velocity.push_back(vel);
                    double coord_x = pos(0);
                    double coord_y = pos(1);

                    //check if if the trajectory face the obstacle
                    if(_homework_tool->isObsFree(coord_x,coord_y,0) != 1){
                        collision = true;
                    }
                    if( fabs(coord_x) >= 5 || fabs(coord_y) >= 5 ){
                        collision = true;
                    }
                    
                    if (firstloop && i == 1 && j == 1){
                        collision = true;                        
                    }
                    
                }


               Eigen::Vector2d target_pt_2d;
               target_pt_2d(0) = target_pt(0);
               target_pt_2d(1) = target_pt(1);
      //          Trajctory_Cost = _homework_tool -> OptimalBVP(pos,vel,target_pt_2d);

                //input the trajetory in the trajectory library
                thisTraLibrary[i][j] = new LatticeState(Position,Velocity,Trajctory_Cost);
                thisTraLibrary[i][j]->loop = thisloop;
                thisTraLibrary[i][j]->cameFrom = fatherptr;
                //if there is not any obstacle in the trajectory we need to set 'collision_check = true', so this trajectory is useable
                if(collision){
                    thisTraLibrary[i][j]->setCollisionfree();
                }
                else{
                    Ptrlist.push_back(thisTraLibrary[i][j]);
                }

  /*              
                //record the min_cost in the trajectory Library, and this is the part pf selecting the best trajectory cloest to the planning traget
                if(Trajctory_Cost<min_Cost && thisTraLibrary[i][j]->collision_check == false){
                    a = i;
                    b = j;
                    min_Cost = Trajctory_Cost;
                }
        */    
        }
    }
 //  TraLibrary_Lattice[a][b] -> setOptimal();
    visTraLibrary(thisTraLibrary);

}


void trajectoryLibrary(const Vector3d start_pt, const Vector3d start_velocity, const Vector3d target_pt)
{
    Vector2d acc_input;
    Vector2d pos,vel;
    int a =0 ;
    int b =0 ;

    double min_Cost = 100000.0;
    double Trajctory_Cost;
    TraLibrary  = new TrajectoryStatePtr * [_discretize_step + 1];     //recored all trajectories after input

    for(int i=0; i <= _discretize_step; i++){           //acc_input_ax
        TraLibrary[i] = new TrajectoryStatePtr  [_discretize_step + 1];
        for(int j=0;j <= _discretize_step; j++){        //acc_input_ay

              
                vector<Vector2d> Position;
                vector<Vector2d> Velocity;
                acc_input(0) = double(-_max_input_acc + i * (2 * _max_input_acc / double(_discretize_step)) );
                acc_input(1) = double(-_max_input_acc + j * (2 * _max_input_acc / double(_discretize_step)) );
                
                pos(0) = start_pt(0);
                pos(1) = start_pt(1);

                vel(0) = start_velocity(0);
                vel(1) = start_velocity(1);

                Position.push_back(pos);
                Velocity.push_back(vel);

                bool collision = false;
                double delta_time;
                delta_time = _time_interval / double(_time_step);
                
                for(int step=0 ; step<=_time_step ; step ++){

                    /*
                    
                    STEP 1: finish the forward integration, the modelling has been given in the document
                    the parameter of forward integration: _max_input_acc|_discretize_step|_time_interval|_time_step   all have been given
                    use the pos and vel to recored the steps in the trakectory

                    */
                    pos(0) = pos(0) + vel(0)*delta_time + 0.5*acc_input(0)*delta_time*delta_time;
                    pos(1) = pos(1) + vel(1)*delta_time + 0.5*acc_input(1)*delta_time*delta_time;

                    vel(0) = vel(0) + acc_input(0)*delta_time;
                    vel(1) = vel(1) + acc_input(1)*delta_time;

                                       
                    Position.push_back(pos);
                    Velocity.push_back(vel);
                    double coord_x = pos(0);
                    double coord_y = pos(1);

                    //check if if the trajectory face the obstacle
                    /*
                    if(_homework_tool->isObsFree(coord_x,coord_y,0) != 1){
                        collision = true;
                    }
                    */
                }
                /*
                    STEP 2: go to the hw_tool.cpp and finish the function Homeworktool::OptimalBVP
                    the solving process has been given in the document

                    because the final point of trajectory is the start point of OBVP, so we input the pos,vel to the OBVP

                    after finish Homeworktool::OptimalBVP, the Trajctory_Cost will record the optimal cost of this trajectory


                */
               Eigen::Vector2d target_pt_2d;
               target_pt_2d(0) = target_pt(0);
               target_pt_2d(1) = target_pt(1);
                Trajctory_Cost = _homework_tool -> OptimalBVP(pos,vel,target_pt_2d);

                //input the trajetory in the trajectory library
                TraLibrary[i][j] = new TrajectoryState(Position,Velocity,Trajctory_Cost);
                
                //if there is not any obstacle in the trajectory we need to set 'collision_check = true', so this trajectory is useable
                if(collision)
                    TraLibrary[i][j]->setCollisionfree();
                
                //record the min_cost in the trajectory Library, and this is the part pf selecting the best trajectory cloest to the planning traget
                if(Trajctory_Cost<min_Cost && TraLibrary[i][j]->collision_check == false){
                    a = i;
                    b = j;
                    min_Cost = Trajctory_Cost;
                }
            
        }
    }
    TraLibrary[a][b] -> setOptimal();
  //  visTraLibrary(TraLibrary);
    return;
}

int main(int argc, char** argv)
{
    ros::init(argc, argv, "demo_node");
    ros::NodeHandle nh("~");

    _map_sub  = nh.subscribe( "map",       1, rcvPointCloudCallBack );
    _pts_sub  = nh.subscribe( "waypoints", 1, rcvWaypointsCallback );

    _grid_map_vis_pub         = nh.advertise<sensor_msgs::PointCloud2>("grid_map_vis", 1);
    _path_vis_pub             = nh.advertise<visualization_msgs::MarkerArray>("RRTstar_path_vis",1);
    _grid_path_vis_pub            = nh.advertise<visualization_msgs::Marker>("grid_path_vis", 1);
    _visited_nodes_vis_pub        = nh.advertise<visualization_msgs::Marker>("visited_nodes_vis",1);    

    nh.param("map/cloud_margin",  _cloud_margin, 0.0);
    nh.param("map/resolution",    _resolution,   0.2);
    
    nh.param("map/x_size",        _x_size, 50.0);
    nh.param("map/y_size",        _y_size, 50.0);
    nh.param("map/z_size",        _z_size, 5.0 );
    
    nh.param("planning/start_x",  _start_pt(0),  0.0);
    nh.param("planning/start_y",  _start_pt(1),  0.0);
    nh.param("planning/start_z",  _start_pt(2),  0.0);

    nh.param("planning/start_vx",  _start_velocity(0),  0.0);
    nh.param("planning/start_vy",  _start_velocity(1),  0.0);
    nh.param("planning/start_vz",  _start_velocity(2),  0.0);    
    
    _map_lower << - _x_size/2.0, - _y_size/2.0,     0.0;
    _map_upper << + _x_size/2.0, + _y_size/2.0, _z_size;
    
    _inv_resolution = 1.0 / _resolution;
    
    _max_x_id = (int)(_x_size * _inv_resolution);
    _max_y_id = (int)(_y_size * _inv_resolution);
    _max_z_id = (int)(_z_size * _inv_resolution);

    //_homework_tool  = new Homeworktool();
    //_homework_tool  -> initGridMap(_resolution, _map_lower, _map_upper, _max_x_id, _max_y_id, _max_z_id);

    _astar_path_finder  = new AstarPathFinder();
    _astar_path_finder  -> initHybridGridMap(_resolution, _map_lower, _map_upper, _max_x_id, _max_y_id, _max_z_id);
    ROS_INFO("int main ok");
    
    ros::Rate rate(100);
    bool status = ros::ok();
    while(status) 
    {
        ros::spinOnce();      
        status = ros::ok();
        rate.sleep();
    }

//    delete _homework_tool;
    delete _astar_path_finder;
    return 0;
}

void visTraLibrary(LatticeStatePtr ** TraLibrary)
{
    double _resolution = 0.2;

    visualization_msgs::Marker       Line;

    Line.header.frame_id = "world";
    Line.header.stamp    = ros::Time::now();
    Line.ns              = "demo_node/TraLibrary";
    Line.action          = visualization_msgs::Marker::ADD;
    Line.pose.orientation.w = 1.0;
    Line.type            = visualization_msgs::Marker::LINE_STRIP;
    Line.scale.x         = _resolution/20;

    Line.color.r         = 0.0;
    Line.color.g         = 0.0;
    Line.color.b         = 1.0;
    Line.color.a         = 1.0;



    for(int i = 0; i <= _discretize_step; i++){
        for(int j = 0; j<= _discretize_step;j++){  

                if(TraLibrary[i][j]->collision_check == false){
                    if(TraLibrary[i][j]->optimal_flag == true){
                        Line.color.r         = 0.0;
                        Line.color.g         = 1.0;
                        Line.color.b         = 0.0;
                        Line.color.a         = 1.0;
                    }else{
                        Line.color.r         = 0.0;
                        Line.color.g         = 0.0;
                        Line.color.b         = 1.0;
                        Line.color.a         = 1.0;
                    }
                }else{
                    Line.color.r         = 1.0;
                    Line.color.g         = 0.0;
                    Line.color.b         = 0.0;
                    Line.color.a         = 1.0;
                }
                   Line.points.clear();
                    geometry_msgs::Point pt;
                    Line.id = marker_id;
                    for(int index = 0; index < int(TraLibrary[i][j]->Position.size());index++){
                        Vector2d coord = TraLibrary[i][j]->Position[index];
                        pt.x = coord(0);
                        pt.y = coord(1);
                        pt.z = 0;
                        Line.points.push_back(pt);
                    }
                    LineArray.markers.push_back(Line);
                    _path_vis_pub.publish(LineArray);
                    ++marker_id; 
            
        }
    }    
}



void visGridPath( vector<Vector2d> nodes )
{   
    visualization_msgs::Marker node_vis; 
    node_vis.header.frame_id = "world";
    node_vis.header.stamp = ros::Time::now();
    
    node_vis.ns = "demo_node/astar_path";

    node_vis.type = visualization_msgs::Marker::CUBE_LIST;
    node_vis.action = visualization_msgs::Marker::ADD;
    node_vis.id = 0;

    node_vis.pose.orientation.x = 0.0;
    node_vis.pose.orientation.y = 0.0;
    node_vis.pose.orientation.z = 0.0;
    node_vis.pose.orientation.w = 1.0;


    
    node_vis.color.a = 1.0;
    node_vis.color.r = 0.0;
    node_vis.color.g = 1.0;
    node_vis.color.b = 0.0;
    


    node_vis.scale.x = _resolution;
    node_vis.scale.y = _resolution;
    node_vis.scale.z = _resolution;

    geometry_msgs::Point pt;
    for(int i = 0; i < int(nodes.size()); i++)
    {
        Vector2d coord = nodes[i];
        pt.x = coord(0);
        pt.y = coord(1);
        pt.z = 0;

        node_vis.points.push_back(pt);
    }
    ROS_WARN("visulizing* " );
     _grid_path_vis_pub.publish(node_vis);
}


void visHybridGridPath( HybridNodePtr ptr )
{   
    double _resolution = 0.2;

    visualization_msgs::Marker       Line;

    Line.header.frame_id = "world";
    Line.header.stamp    = ros::Time::now();
    Line.ns              = "demo_node/TraLibrary";
    Line.action          = visualization_msgs::Marker::ADD;
    Line.pose.orientation.w = 1.0;
    Line.type            = visualization_msgs::Marker::LINE_STRIP;
    Line.scale.x         = _resolution/20;

    Line.color.r         = 0.0;
    Line.color.g         = 0.0;
    Line.color.b         = 1.0;
    Line.color.a         = 1.0;


    Line.points.clear();
    geometry_msgs::Point pt;
    HybridNodePtr tmpptr;
    while (ptr -> cameFrom != NULL){
        Line.id = marker_id;
        for ( auto x:ptr->Positionpts){
            pt.x = x(0);
            pt.y = x(1);
            pt.z = 0;
            Line.points.push_back(pt);           
        }
        LineArray.markers.push_back(Line);
         _path_vis_pub.publish(LineArray);
        ptr = ptr->cameFrom;         
        ++marker_id;         
    }
}

void visVisitedNode( vector<Vector2d> nodes )
{   
    visualization_msgs::Marker node_vis; 
    node_vis.header.frame_id = "world";
    node_vis.header.stamp = ros::Time::now();
    node_vis.ns = "demo_node/expanded_nodes";
    node_vis.type = visualization_msgs::Marker::CUBE_LIST;
    node_vis.action = visualization_msgs::Marker::ADD;
    node_vis.id = 0;

    node_vis.pose.orientation.x = 0.0;
    node_vis.pose.orientation.y = 0.0;
    node_vis.pose.orientation.z = 0.0;
    node_vis.pose.orientation.w = 1.0;
    node_vis.color.a = 0.5;
    node_vis.color.r = 0.0;
    node_vis.color.g = 0.0;
    node_vis.color.b = 1.0;

    node_vis.scale.x = _resolution;
    node_vis.scale.y = _resolution;
    node_vis.scale.z = _resolution;

    geometry_msgs::Point pt;
    for(int i = 0; i < int(nodes.size()); i++)
    {
        Vector2d coord = nodes[i];
        pt.x = coord(0);
        pt.y = coord(1);

        node_vis.points.push_back(pt);
    }

   _visited_nodes_vis_pub.publish(node_vis);
}