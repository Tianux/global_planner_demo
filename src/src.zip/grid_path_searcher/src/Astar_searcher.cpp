#include "Astar_searcher.h"
#include <visualization_msgs/MarkerArray.h>
#include <visualization_msgs/Marker.h>
#include "rs.h"
using namespace std;
using namespace Eigen;
int hybrid_lattice_step = 1;
int turn_step = 4;
double hybrid_lattice_max_input_acc = 0.5;//1.4;
double max_turn = M_PI / 3;
double hybrid_time_interval     = 1.0;//1.25;
int    hybrid_time_step         = 25;
int temp_mark_id = 0;
bool final_flag = false;
double wheel_R = 1.0;//0.2;
double agv_para_a = 0.4;
extern ros::Publisher   _path_vis_pub;
visualization_msgs::MarkerArray  tmpLineArray;
void AstarPathFinder::initGridMap(double _resolution, Vector3d global_xyz_l, Vector3d global_xyz_u, int max_x_id, int max_y_id, int max_z_id)
{   
    gl_xl = global_xyz_l(0);
    gl_yl = global_xyz_l(1);
    gl_zl = global_xyz_l(2);

    gl_xu = global_xyz_u(0);
    gl_yu = global_xyz_u(1);
    gl_zu = global_xyz_u(2);
    
    GLX_SIZE = max_x_id;
    GLY_SIZE = max_y_id;

    GLXY_SIZE  = GLX_SIZE * GLY_SIZE;


    resolution = _resolution;
    inv_resolution = 1.0 / _resolution;    

    data = new uint8_t[GLXY_SIZE];
    memset(data, 0, GLXY_SIZE * sizeof(uint8_t));
    
    GridNodeMap = new GridNodePtr * [GLX_SIZE];
    for(int i = 0; i < GLX_SIZE; i++){
        GridNodeMap[i] = new GridNodePtr  [GLY_SIZE];
        for(int j = 0; j < GLY_SIZE; j++){
            Vector2i tmpIdx(i,j);
            Vector2d pos = gridIndex2coord(tmpIdx);
                GridNodeMap[i][j] = new GridNode(tmpIdx, pos);
        }
    }
    ROS_WARN("finish init")  ;
}

void AstarPathFinder::initHybridGridMap(double _resolution, Vector3d global_xyz_l, Vector3d global_xyz_u, int max_x_id, int max_y_id, int max_z_id)
{   
    gl_xl = global_xyz_l(0);
    gl_yl = global_xyz_l(1);
    gl_zl = global_xyz_l(2);

    gl_xu = global_xyz_u(0);
    gl_yu = global_xyz_u(1);
    gl_zu = global_xyz_u(2);
    
    GLX_SIZE = max_x_id;
    GLY_SIZE = max_y_id;

    GLXY_SIZE  = GLX_SIZE * GLY_SIZE;


    resolution = _resolution;
    inv_resolution = 1.0 / _resolution;    

    data = new uint8_t[GLXY_SIZE];
    memset(data, 0, GLXY_SIZE * sizeof(uint8_t));
    
    HybridNodeMap = new HybridNodePtr * [GLX_SIZE];
    for(int i = 0; i < GLX_SIZE; i++){
        HybridNodeMap[i] = new HybridNodePtr  [GLY_SIZE];
        for(int j = 0; j < GLY_SIZE; j++){
            Vector2i tmpIdx(i,j);
            Vector2d pos = gridIndex2coord(tmpIdx);
                HybridNodeMap[i][j] = new HybridNode(tmpIdx, pos);
        }
    }
    ROS_WARN("Hybrid finish init")  ;
}

void AstarPathFinder::resetGrid(GridNodePtr ptr)
{
    ptr->id = 0;
    ptr->cameFrom = NULL;
    ptr->gScore = inf;
    ptr->fScore = inf;
}

void AstarPathFinder::resetHybridGrid(HybridNodePtr ptr)
{
    ptr->id = 0;
    ptr->cameFrom = NULL;
    ptr->gScore = inf;
    ptr->fScore = inf;
}

void AstarPathFinder::resetUsedGrids()
{   
    for(int i=0; i < GLX_SIZE ; i++)
        for(int j=0; j < GLY_SIZE ; j++)
            resetGrid(GridNodeMap[i][j]);
}

void AstarPathFinder::resetHybridUsedGrids()
{   
    for(int i=0; i < GLX_SIZE ; i++){
        for(int j=0; j < GLY_SIZE ; j++){
            resetHybridGrid(HybridNodeMap[i][j]);
        }
    }
    final_flag = false;
    temp_mark_id = 0;
}

void AstarPathFinder::setObs(const double coord_x, const double coord_y)
{   
    if( coord_x < gl_xl  || coord_y < gl_yl   || 
        coord_x >= gl_xu || coord_y >= gl_yu )
        return;

    int idx_x = static_cast<int>( (coord_x - gl_xl) * inv_resolution);
    int idx_y = static_cast<int>( (coord_y - gl_yl) * inv_resolution);  

    data[idx_x * GLY_SIZE + idx_y] = 1;
}

vector<Vector2d> AstarPathFinder::getVisitedNodes()
{   
    vector<Vector2d> visited_nodes;
    for(int i = 0; i < GLX_SIZE; i++){
        for(int j = 0; j < GLY_SIZE; j++)
            {  
                //if(GridNodeMap[i][j][k]->id != 0) // visualize all nodes in open and close list
                if(GridNodeMap[i][j]->id == -1)  // visualize nodes in close list only
                    visited_nodes.push_back(GridNodeMap[i][j]->coord);
            }
    }

    ROS_WARN("visited_nodes size : %d", visited_nodes.size());
    return visited_nodes;
}

Vector2d AstarPathFinder::gridIndex2coord(const Vector2i & index) 
{
    Vector2d pt;

    pt(0) = ((double)index(0) + 0.5) * resolution + gl_xl;
    pt(1) = ((double)index(1) + 0.5) * resolution + gl_yl;

    return pt;
}


Vector2i AstarPathFinder::coord2gridIndex(const Vector2d & pt) 
{
    Vector2i idx;
    idx <<  min( max( int( (pt(0) - gl_xl) * inv_resolution), 0), GLX_SIZE - 1),
            min( max( int( (pt(1) - gl_yl) * inv_resolution), 0), GLY_SIZE - 1);                  
  
    return idx;
}

Eigen::Vector2d AstarPathFinder::coordRounding(const Eigen::Vector2d & coord)
{
    return gridIndex2coord(coord2gridIndex(coord));
}

inline bool AstarPathFinder::isOccupied(const Eigen::Vector2i & index) const
{
    return isOccupied(index(0), index(1));
}

inline bool AstarPathFinder::isFree(const Eigen::Vector2i & index) const
{
    return isFree(index(0), index(1));
}

inline bool AstarPathFinder::isOccupied(const int & idx_x, const int & idx_y) const 
{
    return  (idx_x >= 0 && idx_x < GLX_SIZE && idx_y >= 0 && idx_y < GLY_SIZE&& (data[idx_x * GLY_SIZE + idx_y] == 1));
}

inline bool AstarPathFinder::isFree(const int & idx_x, const int & idx_y) const 
{
    return (idx_x >= 0 && idx_x < GLX_SIZE && idx_y >= 0 && idx_y < GLY_SIZE  && (data[idx_x * GLY_SIZE + idx_y] < 1));
}

inline void AstarPathFinder::AstarGetSucc(GridNodePtr currentPtr, vector<GridNodePtr> & neighborPtrSets, vector<double> & edgeCostSets)
{   
    neighborPtrSets.clear();
    edgeCostSets.clear();
    /*
    STEP 4: finish AstarPathFinder::AstarGetSucc yourself 
    please write your code below
    */
   Eigen::Vector2i thisNode = currentPtr->index;
   int thisx = thisNode[0];
   int thisy = thisNode[1];

   auto this_coord = currentPtr ->coord; 
 //  int nx, ny, nz;
   double dist;
 //  GridNodePtr temp_ptr = nullptr;
   Eigen::Vector2d n_coord;
   for (int i = thisx - 1; i <= thisx+1; i++){
       for (int j = thisy - 1; j<= thisy+1 ; j++){
               if (i == thisx && j == thisy){
                   continue;
               }
               if( (i < 0) || (i > (GLX_SIZE - 1)) || (j < 0) || (j > (GLY_SIZE - 1) )){
                   continue;
                }
               if (isOccupied(i,j)){
                   continue;
               }
               if (GridNodeMap[i][j]->id == -1){
                   continue;
               }
               n_coord = GridNodeMap[i][j]->coord;
               dist = std::sqrt( (n_coord[0] - this_coord[0]) * (n_coord[0] - this_coord[0])+
                        (n_coord[1] - this_coord[1]) * (n_coord[1] - this_coord[1]));
                neighborPtrSets.push_back(GridNodeMap[i][j]); // calculate the cost in edgeCostSets: inf means that is not unexpanded
                edgeCostSets.push_back(dist); // put the cost inot edgeCostSets               
           
       }

   }
}


inline void AstarPathFinder::HybridGetSucc(HybridNodePtr currentPtr, vector<HybridNodePtr> & neighborPtrSets, vector<double> & edgeCostSets)
{   
    neighborPtrSets.clear();
    edgeCostSets.clear();
    HybridNodePtr ** Expand;
   double dist;

 //  GridNodePtr temp_ptr = nullptr;

   bool occupiedflag =false;
   Vector2d acc_input;
   Vector2d pos,vel;
    double delta_time;
    delta_time = hybrid_time_interval / double(hybrid_time_step);
    double coord_x , coord_y;
    double v_front_old, v_turn_old ;
    double v_turn, v_front;
    double phi,phi_old;
    double theta_old,v_theta_old;
    double theta,v_theta;
    double min_Cost = 100000.0;
    double Trajctory_Cost;
    Expand = new HybridNodePtr * [hybrid_lattice_step+ 1];  

    for(int i=0; i <= hybrid_lattice_step; i++){       
        Expand[i] = new HybridNodePtr  [turn_step + 1];    //acc_input_ax
        for(int j=0;j <=turn_step; j++)
        {        //acc_input_ay
           HybridNodePtr expand_ptr;
            vector<Vector2d> Position;
            vector<Vector2d> Velocity;
        //    acc_input(0) = double(-hybrid_lattice_max_input_acc+ i * (2 * hybrid_lattice_max_input_acc / double(hybrid_lattice_step)) ); // front, phip
        //    acc_input(1) = double(- hybrid_lattice_max_input_acc + j * (2 * hybrid_lattice_max_input_acc / double(turn_step)) );// turn ,phi
            acc_input(0) = double(-hybrid_lattice_max_input_acc+ i * (2 * hybrid_lattice_max_input_acc / double(hybrid_lattice_step)) ); 
            acc_input(1) = double(- max_turn + j * (2 * max_turn / double(turn_step)) );
            pos(0) = currentPtr->coord(0);
            pos(1) = currentPtr->coord(1);
            vel(0) = currentPtr->vel(0);
            vel(1) = currentPtr->vel(1);
            theta_old = currentPtr->theta;
            v_theta_old = currentPtr->v_theta;
            dist = 0;
            Position.push_back(pos);
            Velocity.push_back(vel);
            v_turn_old = currentPtr->omega_turn;
            v_front_old = currentPtr->omega_front;
            phi_old = currentPtr->phi;
            coord_x= pos(0);
            coord_y = pos(1); 
            Vector2i index; 
            for(int step=0 ; step<=hybrid_time_step ; step ++)
            {
                
                v_front =acc_input(0);// v_front_old + acc_input(0)*delta_time;
              //  v_turn = acc_input(1);// = v_turn_old + acc_input(1)*delta_time;
             //  phi = phi_old + v_turn*delta_time;
             phi = acc_input(1);
                if( phi > M_PI/3){
                    phi = M_PI/3;
                }
                else if(phi < -M_PI/3){
                    phi = -M_PI/3;                    
                }
                if (phi==0){
                    v_front = v_front/2;
                }
             //   v_front =1.0 ;
             //   phi = -M_PI/3+double(j*2*M_PI/3/double(hybrid_lattice_step));
                v_theta = wheel_R * sin(phi) / agv_para_a * v_front;
                theta = theta_old + v_theta*delta_time;
                vel(0)=wheel_R * cos(phi) * cos(theta) * v_front;
                vel(1)=wheel_R * cos(phi) * sin(theta) * v_front;
                pos(0) = coord_x + vel(0) * delta_time;
                pos(1) = coord_y + vel(1) * delta_time;
                theta_old = theta;
                v_turn_old = v_turn;
                v_front_old = v_front_old;
                phi_old = phi;
             //   ROS_WARN("vfront : %f", v_front);
               // ROS_WARN("vturn : %f",v_turn);     
              //  ROS_WARN("phi : %f", phi);
               // ROS_WARN("vtheta : %f",theta);     
              //  ROS_WARN("vx : %f", vel(0));
              //  ROS_WARN("vy : %f",vel(1));
               //  ROS_WARN("x : %f", pos(0));
              //  ROS_WARN("y : %f",pos(1));  
                                           
                //pos(0) = pos(0) + vel(0)*delta_time + 0.5*acc_input(0)*delta_time*delta_time;
                //pos(1) = pos(1) + vel(1)*delta_time + 0.5*acc_input(1)*delta_time*delta_time;
                //vel(0) = vel(0) + acc_input(0)*delta_time;
                //vel(1) = vel(1) + acc_input(1)*delta_time;
                Position.push_back(pos);
                Velocity.push_back(vel);
                dist += std::sqrt( (coord_x - pos(0)) * (coord_x - pos(0))+(coord_y - pos(1)) * (coord_y - pos(1)));
                coord_x = pos(0);
                coord_y = pos(1);
                index = coord2gridIndex(pos);
            if ( (coord_x < -(GLX_SIZE )/2) || (coord_x > (GLX_SIZE )/2) || (coord_y < -(GLY_SIZE)/2) || (coord_y > (GLY_SIZE)/2) ){
           //      ROS_WARN("overboundary");
                 occupiedflag = true;

            }
            if (isOccupied(index(0),index(1))){
            //    ROS_WARN("occupied");
                 occupiedflag = true;

            }                
                }
            if (occupiedflag){
                continue;
            }

 //         ROS_WARN("after in the for i:%d",i);        
 //          ROS_WARN("after in the for j :%d",j);              


 //           ROS_WARN("dist : %f", dist);         
            Expand[i][j] = new HybridNode(coord2gridIndex(pos),pos);

 //          ROS_WARN(" acc:%f",acc_input(0));    
 //          ROS_WARN(" acc:%f",acc_input(1));    
            Expand[i][j]->acc = acc_input;
 //          ROS_WARN(" vel");    
            Expand[i][j]->vel = vel;
  //          ROS_WARN(" index");     

 //           ROS_WARN("indexx : %d", expand_ptr->index(0));
 //           ROS_WARN("indexy : %d",expand_ptr->index(1));   
            Expand[i][j]->Positionpts = Position;
            Expand[i][j]->omega_front = v_front;
            Expand[i][j]->omega_turn = v_turn;
            Expand[i][j]->phi = phi;
            Expand[i][j]->theta = theta;
            neighborPtrSets.push_back(Expand[i][j]);
            edgeCostSets.push_back(dist);
            visHybridTempPath(Expand[i][j]);

   //         ROS_WARN("after 1loop");     
        }
    }

}


double AstarPathFinder::getHeu(GridNodePtr node1, GridNodePtr node2)
{
    
    /* 
    choose possible heuristic function you want
    Manhattan, Euclidean, Diagonal, or 0 (Dijkstra)
    Remember tie_breaker learned in lecture, add it here ?

    STEP 1: finish the AstarPathFinder::getHeu , which is the heuristic function
    please write your code below
    *
    *
    */
    double distance =std::sqrt(  (node1->coord(0) - node2->coord(0)) * (node1->coord(0) - node2->coord(0)) + 
    (node1->coord(1) - node2->coord(1))* (node1->coord(1) - node2->coord(1))  ) ;
    return distance;
}

double AstarPathFinder::HybridgetHeu(HybridNodePtr node1, HybridNodePtr node2)
{
    ReedsSheppStateSpace   *r=new ReedsSheppStateSpace;
    ReedsSheppStateSpace::ReedsSheppPath *rr=new ReedsSheppStateSpace::ReedsSheppPath;    
    double q0[3]={node1->coord(0),node1->coord(1),node1->theta};
    double q1[3]={node2->coord(0),node2->coord(1),node2->theta};    
    double distance = r->reedsShepp(q0,q1).totalLength_;
    delete rr;
    delete r;
//    double distance =std::sqrt(  (node1->coord(0) - node2->coord(0)) * (node1->coord(0) - node2->coord(0)) + 
//    (node1->coord(1) - node2->coord(1))* (node1->coord(1) - node2->coord(1))  ) ;
    return distance;
}

void AstarPathFinder::AstarGraphSearch(Vector2d start_pt, Vector2d end_pt)
{   
    ros::Time time_1 = ros::Time::now();    


    //index of start_point and end_point
    Vector2i start_idx = coord2gridIndex(start_pt);
    Vector2i end_idx   = coord2gridIndex(end_pt);
    goalIdx = end_idx;

    //position of start_point and end_point
    start_pt = gridIndex2coord(start_idx);
    end_pt   = gridIndex2coord(end_idx);

    //Initialize the pointers of struct GridNode which represent start node and goal node
    GridNodePtr startPtr = new GridNode(start_idx, start_pt);
    GridNodePtr endPtr   = new GridNode(end_idx,   end_pt);

    //openSet is the open_list implemented through multimap in STL library
    openSet.clear();
    // currentPtr represents the node with lowest f(n) in the open_list
    GridNodePtr currentPtr  = NULL;
    GridNodePtr neighborPtr = NULL;

    //put start node in open set
    startPtr -> gScore = 0;
    startPtr -> fScore = getHeu(startPtr,endPtr);   
    //STEP 1: finish the AstarPathFinder::getHeu , which is the heuristic function
    startPtr -> id = 1; 
    startPtr -> coord = start_pt;
    openSet.insert( make_pair(startPtr -> fScore, startPtr) );
    /*
    STEP 2 :  some else preparatory works which should be done before while loop
    please write your code below
    */
    GridNodeMap[start_idx[0]][start_idx[1]] -> id = 1;   

    Eigen::Vector2i current_idx; 
    vector<GridNodePtr> neighborPtrSets;
    vector<double> edgeCostSets;

    // this is the main loop
    while ( !openSet.empty() ){
        /*
        *
        *
        step 3: Remove the node with lowest cost function from open set to closed set
        please write your code below
        
        IMPORTANT NOTE!!!
        This part you should use the C++ STL: multimap, more details can be find in Homework description
        *
        *
        */
        currentPtr = openSet.begin() -> second; // first T1, second T2
        openSet.erase(openSet.begin()); // remove the node with minimal f value
        current_idx = currentPtr->index;
        GridNodeMap[current_idx[0]][current_idx[1]] -> id = -1;// update the id in grid node map
        // if the current node is the goal 
        if( currentPtr->index == goalIdx ){
            ros::Time time_2 = ros::Time::now();
            terminatePtr = currentPtr;
            ROS_WARN("[A*]{sucess}  Time in A*  is %f ms, path cost if %f m", (time_2 - time_1).toSec() * 1000.0, currentPtr->gScore * resolution );            
            return;
        }
        //get the succetion
        AstarGetSucc(currentPtr, neighborPtrSets, edgeCostSets);  //STEP 4: finish AstarPathFinder::AstarGetSucc yourself     

        /*
        *
        *
        STEP 5:  For all unexpanded neigbors "m" of node "n", please finish this for loop
        please write your code below
        *        
        */         
        for(int i = 0; i < (int)neighborPtrSets.size(); i++){
            /*
            *
            *
            Judge if the neigbors have been expanded
            please write your code below
            
            IMPORTANT NOTE!!!
            neighborPtrSets[i]->id = -1 : unexpanded
            neighborPtrSets[i]->id = 1 : expanded, equal to this node is in close set
            *        
            */
            neighborPtr = neighborPtrSets[i];
            if(neighborPtr -> id ==0 ){
                neighborPtr ->gScore = currentPtr ->gScore + edgeCostSets[i];
                neighborPtr ->fScore = getHeu(neighborPtr,endPtr) + neighborPtr ->gScore;
                neighborPtr ->cameFrom = currentPtr;
                openSet.insert(make_pair(neighborPtr->fScore,neighborPtr));
                neighborPtr -> id = 1;
            
            } 
            else if( neighborPtr ->id == 1)
            {
                if (neighborPtr ->gScore > currentPtr->gScore + edgeCostSets[i]){
                    neighborPtr ->gScore = currentPtr ->gScore + edgeCostSets[i];
                    neighborPtr ->fScore = getHeu(neighborPtr,endPtr) + neighborPtr ->gScore;
                    neighborPtr ->cameFrom = currentPtr;       
                }
                //this node is in open set and need to judge if it needs to update, the "0" should be deleted when you are coding
                /*
                *
                *
                STEP 7:  As for a node in open set, update it , maintain the openset ,and then put neighbor in open set and record it
                please write your code below
                *        
                */               
            }
            else{//this node is in closed set
                /*
                *
                please write your code below
                *        
                */
                continue;
            }
        }      
 //       ROS_WARN("running now" );
    }
    //if search fails
    ros::Time time_2 = ros::Time::now();
    if((time_2 - time_1).toSec() > 0.1)
        ROS_WARN("Time consume in Astar path finding is %f", (time_2 - time_1).toSec() );
}

void AstarPathFinder::HybridAstarGraphSearch(Vector2d start_pt, Vector2d end_pt)
{   
    ros::Time time_1 = ros::Time::now();    
    int loopcount =0 ;
    //index of start_point and end_point
    Vector2i start_idx = coord2gridIndex(start_pt);
    Vector2i end_idx   = coord2gridIndex(end_pt);
    goalIdx = end_idx;

    //position of start_point and end_point
    start_pt = gridIndex2coord(start_idx);
  //  end_pt   = gridIndex2coord(end_idx);

    //Initialize the pointers of struct GridNode which represent start node and goal node
    HybridNodePtr startPtr = new HybridNode(start_idx, start_pt);
    HybridNodePtr endPtr   = new HybridNode(end_idx,   end_pt);

    //openSet is the open_list implemented through multimap in STL library
    HybridOpenSet.clear();
    // currentPtr represents the node with lowest f(n) in the open_list
    HybridNodePtr currentPtr  = NULL;
    HybridNodePtr neighborPtr = NULL;

    //put start node in open set
    startPtr -> gScore = 0;
    startPtr -> fScore = HybridgetHeu(startPtr,endPtr);   
    startPtr -> id = 1; 
    startPtr -> coord = start_pt;
    startPtr-> vel(0) = 0;
    startPtr-> vel(1) = 0;   
    startPtr-> phi = 0;
    startPtr->theta = 0;
    startPtr->omega_front = 0;
    startPtr->omega_turn = 0;
    HybridOpenSet.insert( make_pair(startPtr -> fScore, startPtr) );
    /*
    STEP 2 :  some else preparatory works which should be done before while loop
    please write your code below
    */

    Eigen::Vector2i current_idx; 
    vector<HybridNodePtr> neighborPtrSets;
    vector<double> edgeCostSets;
    ROS_WARN("ready to in the loop");
    // this is the main loop
    while ( !HybridOpenSet.empty() ){
 //       ROS_WARN(" loop ++ ");
        loopcount++;
        currentPtr = HybridOpenSet.begin() -> second; // first T1, second T2
        HybridOpenSet.erase(HybridOpenSet.begin()); // remove the node with minimal f value
        current_idx = currentPtr->index;
        HybridNodeMap[current_idx(0)][current_idx(1)] -> id = -1;// update the id in grid node map
        // if the current node is the goal 
        if( currentPtr->index == goalIdx ){
            ros::Time time_2 = ros::Time::now();
            HybridTerminatePtr = currentPtr;
            visHybridFinalPath(HybridTerminatePtr);
            ROS_WARN("[A*]{sucess}  Time in A*  is %f ms, path cost if %f m", (time_2 - time_1).toSec() * 1000.0, currentPtr->gScore * resolution );            
            return;
        }
        //get the succetion
  //       ROS_WARN("before get succ" );       
        HybridGetSucc(currentPtr, neighborPtrSets, edgeCostSets);  //STEP 4: finish AstarPathFinder::AstarGetSucc yourself     
   //     ROS_WARN("after get succ" );

        for(int i = 0; i < (int)neighborPtrSets.size(); i++){

            neighborPtr = neighborPtrSets[i];
            int tmpid = HybridNodeMap[neighborPtr->index(0)][neighborPtr->index(1)]->id;
            if(tmpid ==0 ){
  //              ROS_WARN("0" );
                neighborPtr ->gScore = currentPtr ->gScore + edgeCostSets[i];
                neighborPtr ->fScore = HybridgetHeu(neighborPtr,endPtr) + neighborPtr ->gScore;
                neighborPtr ->cameFrom = currentPtr;
                HybridOpenSet.insert(make_pair(neighborPtr->fScore,neighborPtr));
                HybridNodeMap[neighborPtr->index(0)][neighborPtr->index(1)] -> id = 1;
  //              ROS_WARN("running now in id = 0" );
            } 
            else if( tmpid == 1)
            {
 //               ROS_WARN("1" );
                if (neighborPtr ->gScore > currentPtr->gScore + edgeCostSets[i]){
                    neighborPtr ->gScore = currentPtr ->gScore + edgeCostSets[i];
                    neighborPtr ->fScore = HybridgetHeu(neighborPtr,endPtr) + neighborPtr ->gScore;
                    neighborPtr ->cameFrom = currentPtr;       
    //                    ROS_WARN("running now in id=1" );    
                }
            
            }
            else{//this node is in closed set

                continue;
            }
        }
 //       ROS_WARN("indexx %f",currentPtr->coord(0));      
 //       ROS_WARN("indexy %f",currentPtr->coord(1));  
        if (loopcount >=10000){
            ROS_WARN("overloop");
            _path_vis_pub.publish(tmpLineArray);
            //HybridTerminatePtr = currentPtr;
            break;
        }
    }
    //if search fails
    ros::Time time_2 = ros::Time::now();
    if((time_2 - time_1).toSec() > 0.1)
        ROS_WARN("Time consume in Astar path finding is %f", (time_2 - time_1).toSec() );
}


vector<Vector2d> AstarPathFinder::getPath() 
{   
    vector<Vector2d> path;
    vector<GridNodePtr> gridPath;
    /*
    *
    *
    STEP 8:  trace back from the curretnt nodePtr to get all nodes along the path
    please write your code below
    *      
    */
    auto ptr = terminatePtr;
    while (ptr -> cameFrom != NULL){
        gridPath.push_back(ptr);
        ptr = ptr->cameFrom;
    }
    for (auto ptr: gridPath)
        path.push_back(ptr->coord);
        
    reverse(path.begin(),path.end());

    return path;
}

HybridNodePtr AstarPathFinder::HybridgetPath() 
{   
    vector<Vector2d> path;
    vector<HybridNodePtr> gridPath;

    auto ptr = HybridTerminatePtr;
   /* 
    while (ptr -> cameFrom != NULL){
        gridPath.push_back(ptr);
        ptr = ptr->cameFrom;
    }
    for (auto ptr: gridPath)
        path.push_back(ptr->coord);
        
    reverse(path.begin(),path.end());
*/
    return ptr;
}

void AstarPathFinder::visHybridTempPath( HybridNodePtr ptr )
{   
    
    double _resolution = 0.2;

    visualization_msgs::Marker       Line;

    Line.header.frame_id = "world";
    Line.header.stamp    = ros::Time::now();
    Line.ns              = "demo_node/TraLibrary";
    Line.action          = visualization_msgs::Marker::ADD;
    Line.pose.orientation.w = 1.0;
    Line.type            = visualization_msgs::Marker::LINE_STRIP;
    Line.scale.x         = _resolution/20;

    Line.color.r         = 0.0;
    Line.color.g         = 0.0;
    Line.color.b         = 1.0;
    Line.color.a         = 0.3;
    if (final_flag){
    Line.color.r         = 0.0;
    Line.color.g         = 1.0;
    Line.color.b         = 0.0;
    Line.color.a         = 1.0;        
    Line.scale.x         = _resolution/10;
    }

    Line.points.clear();
    geometry_msgs::Point pt;
   
        Line.id = temp_mark_id ;
        for ( auto x:ptr->Positionpts){
            pt.x = x(0);
            pt.y = x(1);
            pt.z = 0;
            Line.points.push_back(pt);           
        }
        tmpLineArray.markers.push_back(Line);
      _path_vis_pub.publish(tmpLineArray);
 
        ++temp_mark_id ;         
    
}

void AstarPathFinder::visHybridFinalPath( HybridNodePtr ptr ) {
    final_flag = true;
    while (ptr->cameFrom != NULL){
    visHybridTempPath(ptr);
    ptr=ptr->cameFrom;
    }
    ROS_INFO("finish vis");
}